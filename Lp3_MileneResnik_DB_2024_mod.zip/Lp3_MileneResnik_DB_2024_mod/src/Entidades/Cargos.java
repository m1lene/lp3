package Entidades;

// @author Radames (usando gerador de código) 09:23:49 10/10/2024
public class Cargos {

    private int idCargos;
    private String cargo;

    public Cargos() {

    }

    public Cargos(int idCargos, String cargo) {
        this.idCargos = idCargos;
        this.cargo = cargo;
    }

    public int getIdCargos() {
        return idCargos;
    }

    public String getCargo() {
        return cargo;
    }

    public void setIdCargos(int idCargos) {
        this.idCargos = idCargos;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String toString() {
        return this.idCargos + ";" + this.cargo;
    }
}

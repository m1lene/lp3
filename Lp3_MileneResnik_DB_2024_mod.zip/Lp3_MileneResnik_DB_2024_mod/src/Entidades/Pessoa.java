package Entidades;

// @author Radames (usando gerador de código) 09:24:00 10/10/2024
import java.util.Date;

public class Pessoa {

    private String cpfPessoa;
    private String nomePessoa;
    private Date dataNascimento;

    public Pessoa() {

    }

    public Pessoa(String cpfPessoa, String nomePessoa, Date dataNascimento) {
        this.cpfPessoa = cpfPessoa;
        this.nomePessoa = nomePessoa;
        this.dataNascimento = dataNascimento;
    }

    public String getCpfPessoa() {
        return cpfPessoa;
    }

    public String getNomePessoa() {
        return nomePessoa;
    }

    public Date getDataNascimento() {
        return dataNascimento;
    }

    public void setCpfPessoa(String cpfPessoa) {
        this.cpfPessoa = cpfPessoa;
    }

    public void setNomePessoa(String nomePessoa) {
        this.nomePessoa = nomePessoa;
    }

    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String toString() {
        return this.cpfPessoa + ";" + this.nomePessoa + ";" + this.dataNascimento;
    }
}

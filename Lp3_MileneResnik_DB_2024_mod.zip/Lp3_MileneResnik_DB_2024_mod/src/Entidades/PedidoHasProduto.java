package Entidades;

// @author Radames (usando gerador de código) 09:23:58 10/10/2024
public class PedidoHasProduto {

    private int PedidoIdPedido;
    private int ProdutoIdProduto;
    private double precoUnitarioProduto;
    private int quantidade;

    public PedidoHasProduto() {

    }

    public PedidoHasProduto(int PedidoIdPedido, int ProdutoIdProduto, double precoUnitarioProduto, int quantidade) {
        this.PedidoIdPedido = PedidoIdPedido;
        this.ProdutoIdProduto = ProdutoIdProduto;
        this.precoUnitarioProduto = precoUnitarioProduto;
        this.quantidade = quantidade;
    }

    public int getPedidoIdPedido() {
        return PedidoIdPedido;
    }

    public int getProdutoIdProduto() {
        return ProdutoIdProduto;
    }

    public double getPrecoUnitarioProduto() {
        return precoUnitarioProduto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setPedidoIdPedido(int PedidoIdPedido) {
        this.PedidoIdPedido = PedidoIdPedido;
    }

    public void setProdutoIdProduto(int ProdutoIdProduto) {
        this.ProdutoIdProduto = ProdutoIdProduto;
    }

    public void setPrecoUnitarioProduto(double precoUnitarioProduto) {
        this.precoUnitarioProduto = precoUnitarioProduto;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String toString() {
        return this.PedidoIdPedido + ";" + this.ProdutoIdProduto + ";" + this.precoUnitarioProduto + ";" + this.quantidade;
    }
}

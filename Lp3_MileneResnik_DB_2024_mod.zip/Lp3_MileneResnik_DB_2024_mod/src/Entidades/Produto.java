package Entidades;

// @author Radames (usando gerador de código) 09:24:02 10/10/2024
public class Produto {

    private int idProduto;
    private String nomeProduto;
    private int quantidadeEstoque;
    private String UnidadeDeMedidaIdUnidadeDeMedida;

    public Produto() {

    }

    public Produto(int idProduto, String nomeProduto, int quantidadeEstoque, String UnidadeDeMedidaIdUnidadeDeMedida) {
        this.idProduto = idProduto;
        this.nomeProduto = nomeProduto;
        this.quantidadeEstoque = quantidadeEstoque;
        this.UnidadeDeMedidaIdUnidadeDeMedida = UnidadeDeMedidaIdUnidadeDeMedida;
    }

    public int getIdProduto() {
        return idProduto;
    }

    public String getNomeProduto() {
        return nomeProduto;
    }

    public int getQuantidadeEstoque() {
        return quantidadeEstoque;
    }

    public String getUnidadeDeMedidaIdUnidadeDeMedida() {
        return UnidadeDeMedidaIdUnidadeDeMedida;
    }

    public void setIdProduto(int idProduto) {
        this.idProduto = idProduto;
    }

    public void setNomeProduto(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }

    public void setQuantidadeEstoque(int quantidadeEstoque) {
        this.quantidadeEstoque = quantidadeEstoque;
    }

    public void setUnidadeDeMedidaIdUnidadeDeMedida(String UnidadeDeMedidaIdUnidadeDeMedida) {
        this.UnidadeDeMedidaIdUnidadeDeMedida = UnidadeDeMedidaIdUnidadeDeMedida;
    }

    public String toString() {
        return this.idProduto + ";" + this.nomeProduto + ";" + this.quantidadeEstoque + ";" + this.UnidadeDeMedidaIdUnidadeDeMedida;
    }
}

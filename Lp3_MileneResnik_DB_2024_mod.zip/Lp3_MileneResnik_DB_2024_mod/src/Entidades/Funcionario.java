package Entidades;

// @author Radames (usando gerador de código) 09:23:54 10/10/2024
public class Funcionario {

    private String PessoacpfPessoa;
    private String salario;
    private int CargosidCargos;

    public Funcionario() {

    }

    public Funcionario(String PessoacpfPessoa, String salario, int CargosidCargos) {
        this.PessoacpfPessoa = PessoacpfPessoa;
        this.salario = salario;
        this.CargosidCargos = CargosidCargos;
    }

    public String getPessoacpfPessoa() {
        return PessoacpfPessoa;
    }

    public String getSalario() {
        return salario;
    }

    public int getCargosidCargos() {
        return CargosidCargos;
    }

    public void setPessoacpfPessoa(String PessoacpfPessoa) {
        this.PessoacpfPessoa = PessoacpfPessoa;
    }

    public void setSalario(String salario) {
        this.salario = salario;
    }

    public void setCargosidCargos(int CargosidCargos) {
        this.CargosidCargos = CargosidCargos;
    }

    public String toString() {
        return this.PessoacpfPessoa + ";" + this.salario + ";" + this.CargosidCargos;
    }
}

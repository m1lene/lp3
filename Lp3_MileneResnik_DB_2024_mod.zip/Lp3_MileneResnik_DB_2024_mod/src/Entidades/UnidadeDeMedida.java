package Entidades;

// @author Radames (usando gerador de código) 09:24:04 10/10/2024
public class UnidadeDeMedida {

    private String idUnidadeDeMedida;
    private String unidadeMedida;

    public UnidadeDeMedida() {

    }

    public UnidadeDeMedida(String idUnidadeDeMedida, String unidadeMedida) {
        this.idUnidadeDeMedida = idUnidadeDeMedida;
        this.unidadeMedida = unidadeMedida;
    }

    public String getIdUnidadeDeMedida() {
        return idUnidadeDeMedida;
    }

    public String getUnidadeMedida() {
        return unidadeMedida;
    }

    public void setIdUnidadeDeMedida(String idUnidadeDeMedida) {
        this.idUnidadeDeMedida = idUnidadeDeMedida;
    }

    public void setUnidadeMedida(String unidadeMedida) {
        this.unidadeMedida = unidadeMedida;
    }

    public String toString() {
        return this.idUnidadeDeMedida + ";" + this.unidadeMedida;
    }
}

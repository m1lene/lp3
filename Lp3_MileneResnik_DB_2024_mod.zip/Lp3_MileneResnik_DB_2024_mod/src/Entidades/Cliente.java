package Entidades;

// @author Radames (usando gerador de código) 09:23:52 10/10/2024
public class Cliente {

    private double limite;
    private String dateCadastro;
    private String PessoaCpfPessoa;

    public Cliente() {

    }

    public Cliente(double limite, String dateCadastro, String PessoaCpfPessoa) {
        this.limite = limite;
        this.dateCadastro = dateCadastro;
        this.PessoaCpfPessoa = PessoaCpfPessoa;
    }

    public double getLimite() {
        return limite;
    }

    public String getDateCadastro() {
        return dateCadastro;
    }

    public String getPessoaCpfPessoa() {
        return PessoaCpfPessoa;
    }

    public void setLimite(double limite) {
        this.limite = limite;
    }

    public void setDateCadastro(String dateCadastro) {
        this.dateCadastro = dateCadastro;
    }

    public void setPessoaCpfPessoa(String PessoaCpfPessoa) {
        this.PessoaCpfPessoa = PessoaCpfPessoa;
    }

    public String toString() {
        return this.limite + ";" + this.dateCadastro + ";" + this.PessoaCpfPessoa;
    }
}

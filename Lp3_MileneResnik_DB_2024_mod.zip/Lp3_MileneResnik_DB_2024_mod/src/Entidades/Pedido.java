package Entidades;

// @author Radames (usando gerador de código) 09:23:56 10/10/2024
import java.util.Date;

public class Pedido {

    private int idPedido;
    private Date data;
    private String ClientePessoacpfPessoa;

    public Pedido() {

    }

    public Pedido(int idPedido, Date data, String ClientePessoacpfPessoa) {
        this.idPedido = idPedido;
        this.data = data;
        this.ClientePessoacpfPessoa = ClientePessoacpfPessoa;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public Date getData() {
        return data;
    }

    public String getClientePessoacpfPessoa() {
        return ClientePessoacpfPessoa;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public void setClientePessoacpfPessoa(String ClientePessoacpfPessoa) {
        this.ClientePessoacpfPessoa = ClientePessoacpfPessoa;
    }

    public String toString() {
        return this.idPedido + ";" + this.data + ";" + this.ClientePessoacpfPessoa;
    }
}

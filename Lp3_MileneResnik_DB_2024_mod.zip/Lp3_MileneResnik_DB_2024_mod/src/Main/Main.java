package Main;

import GUIs.MenuPrincipalGUI;
import java.awt.Dimension;

/**
 *
 * @author radames
 */
public class Main {
    
    public static void main(String[] args) {
         
        MenuPrincipalGUI guiMenuPrincipal = new MenuPrincipalGUI(new Dimension(800,600));


    }

}

package DAOs;

import Entidades.Funcionario;
import java.util.List;

public class DAOFuncionario extends DAOGenerico<Funcionario> {

    public DAOFuncionario() {
        super();
    }

    public List<String> listarEmOrdemDeNome() {
        DAOFuncionario daoFuncionario = new DAOFuncionario();
        String sql = "SELECT * FROM funcionario ORDER BY PessoacpfPessoa";

        List<String> lp = daoFuncionario.executarSQL(sql);
        if (lp != null) {
            return lp;
        } else {
            return null;
        }
    }

    public static void main(String[] args) {
        DAOFuncionario daoFuncionario = new DAOFuncionario();
        List<String> funcionario = daoFuncionario.listarEmOrdemDeNome();
        for (String pais : funcionario) {
            System.out.println(pais);
        }
    }
}

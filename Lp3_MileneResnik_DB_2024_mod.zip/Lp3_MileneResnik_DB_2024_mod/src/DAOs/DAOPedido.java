package DAOs;

import Entidades.Pedido;
import java.util.List;

public class DAOPedido extends DAOGenerico<Pedido> {

    public DAOPedido() {
        super();
    }

    public List<String> listarEmOrdemDeNome() {
        DAOFuncionario daoFuncionario = new DAOFuncionario();
        String sql = "SELECT * FROM Pedido  ORDER BY idPedido";

        List<String> lp = daoFuncionario.executarSQL(sql);
        if (lp != null) {
            return lp;
        } else {
            return null;
        }
    }

    public static void main(String[] args) {
        DAOPedido daoPedido = new DAOPedido();
        List<String> pedido = daoPedido.listarEmOrdemDeNome();
        for (String pais : pedido) {
            System.out.println(pais);
        }
    }
}

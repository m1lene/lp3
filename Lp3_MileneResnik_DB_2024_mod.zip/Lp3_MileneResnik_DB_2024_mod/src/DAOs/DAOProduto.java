package DAOs;

import Entidades.Produto;
import java.util.List;

public class DAOProduto extends DAOGenerico<Produto> {

    public DAOProduto() {
        super();
    }

    public List<String> listarEmOrdemDeNome() {
        DAOProduto daoProduto = new DAOProduto();
        String sql = "SELECT * FROM Produto ORDER BY nomeProduto";

        List<String> lp = daoProduto.listarComoStrings();
        if (lp != null) {
            return lp;
        } else {
            return null;
        }
    }

    public static void main(String[] args) {
        DAOProduto daoProduto = new DAOProduto();
        List<String> listaProduto = daoProduto.listarEmOrdemDeNome();
        for (String produto : listaProduto) {
            System.out.println(produto);
        }
       
        
    }
}

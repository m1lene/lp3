package DAOs;

import Entidades.Cliente;
import java.util.List;

public class DAOCliente extends DAOGenerico<Cliente> {

    public DAOCliente() {
        super();
    }

    public List<String> listarEmOrdemDeNome() {
        DAOCliente daoCliente = new DAOCliente();
        String sql = "SELECT * FROM Cliente";
        
        List<String> lp = daoCliente.executarSQL(sql);
        if (lp!=null) {
            return lp;
        } else {
            return null;
        }

    }

    public static void main(String[] args) {
        DAOCliente daoCliente = new DAOCliente();
        List<String> cliente = daoCliente.listarEmOrdemDeNome();
        for (String pessoa : cliente) {
            System.out.println(pessoa);
        }

        // Fetching a Pessoa entity by its CPF
//        String cpf = "222"; // Example CPF
//        Pessoa pessoa = daoPessoa.obter(cpf, "cpfPessoa");
//
//        if (pessoa
//                != null) {
//            System.out.println("Pessoa found: " + pessoa);
//        } else {
//            System.out.println("Pessoa not found with CPF: " + cpf);
//        }
    }
}
